package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utility.RecordingActions;
import utility.elementWaitActions;

/**
 * @author surya
 * POM class for Login page
 *
 */
public class gmailLoginPage {
	private WebDriver driver;
	public ExtentTest logger;
	protected elementWaitActions EWA = new elementWaitActions(driver);
	@FindBy(xpath = "//input[@aria-label='Email or phone']")
	private WebElement emailTextBox;
	@FindBy(xpath = "//span[text()='Next']")
	private WebElement nextButton;
	@FindBy(xpath = "//input[@aria-label='Enter your password']")
	private WebElement pwdTextBox;

	/**
	 * @param driver
	 * @param logger
	 */
	public gmailLoginPage(WebDriver driver, ExtentTest logger) {
		// super(driver, logger);
		this.driver = driver;
		this.logger = logger;
		PageFactory.initElements(driver, this);
	}

	/**
	 * @param uname
	 * @param password
	 * @throws InterruptedException
	 */
	public void login(String uname, String password) throws InterruptedException {
		System.out.println(driver.getTitle());
		EWA.WaitUntilElementIsPresent(driver, emailTextBox);
		emailTextBox.clear();
		emailTextBox.sendKeys(uname);
		logger.log(LogStatus.INFO, "Enter email or phone", "Entered the email or phone as "+uname);
		RecordingActions.info("Entered the email or phone as "+uname);
		nextButton.click();
		EWA.WaitUntilElementIsPresent(driver, pwdTextBox);
		pwdTextBox.clear();
		pwdTextBox.sendKeys(password);
		logger.log(LogStatus.INFO, "Enter password", "Entered the password as *********");
		RecordingActions.info("Entered the password as *********");
		nextButton.click();
		Thread.sleep(5000);
		if(driver.getCurrentUrl().equals("https://mail.google.com/mail/u/0/#inbox")) {
			logger.log(LogStatus.PASS, "Login", "Login successfully");
			RecordingActions.info("Login successfully");
		}else {
			logger.log(LogStatus.FAIL, "Login", "Login Failed");
			RecordingActions.info("Login Failed");
		}
	}

}
