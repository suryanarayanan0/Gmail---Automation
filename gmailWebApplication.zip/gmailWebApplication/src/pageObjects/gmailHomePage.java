package pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utility.RecordingActions;
import utility.elementWaitActions;

/**
 * @author surya
 * POM Class for Home page
 *
 */
public class gmailHomePage {
	private WebDriver driver;
	public ExtentTest logger;
	protected elementWaitActions EWA = new elementWaitActions(driver);
	@FindBy(xpath = "//div[text()='Compose']")
	private WebElement composeBtn;
	@FindBy(xpath = "//input[@aria-label='Search mail']")
	private WebElement searchMailBox;
	@FindBy(xpath = "//a[contains(@aria-label,'Google Account:')]")
	private WebElement profileBtn;
	@FindBy(xpath = "//a[text()='Sign out']")
	private WebElement signoutBtn;
	@FindBy(xpath = "//textarea[@aria-label='To']")
	private WebElement toTextBox;
	@FindBy(xpath = "//input[@name='subjectbox']")
	private WebElement subjectTextBox;
	@FindBy(xpath = "//div[@aria-label='Message Body']")
	private WebElement messageTextBox;
	@FindBy(xpath = "//div[text()='Send']")
	private WebElement sentBtn;
	@FindBy(xpath = "//a[@title='Inbox']")
	private WebElement indexMenu;
	@FindBy(xpath = "//span[@class='bog']")
	private List<WebElement> inboxMailBoxesLists;
	@FindBy(xpath = "//div[@role='checkbox']")
	private List<WebElement> inboxcheckMailBoxesLists;
	@FindBy(xpath = "//div[@aria-label='Delete']")
	private WebElement deleteBtn;
	
	/**
	 * @param driver
	 * @param logger
	 */
	public gmailHomePage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		this.logger = logger;
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * @param toMail
	 * @param Subject
	 * @param Message
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	public void composeMail(String toMail,String Subject,String Message) throws InterruptedException, IOException {
		EWA.WaitUntilElementIsPresent(driver, composeBtn);
		composeBtn.click();
		EWA.WaitUntilElementIsPresent(driver, toTextBox);
		toTextBox.clear();
		toTextBox.sendKeys(toMail);
		logger.log(LogStatus.INFO, "Enter to mail", "Entered the email as "+toMail);
		RecordingActions.info("Entered the email as "+toMail);
		EWA.WaitUntilElementIsPresent(driver, subjectTextBox);
		subjectTextBox.clear();
		subjectTextBox.sendKeys(Subject);
		logger.log(LogStatus.INFO, "Enter to subject", "Entered the subject as "+toMail);
		RecordingActions.info("Entered the subject as "+toMail);
		EWA.WaitUntilElementIsPresent(driver, messageTextBox);
		messageTextBox.clear();
		messageTextBox.sendKeys(Message);
		logger.log(LogStatus.INFO, "Enter to message", "Entered the message as "+Message);
		RecordingActions.info("Entered the message as "+Message);
		sentBtn.click();
		Thread.sleep(2000);
		logger.log(LogStatus.INFO, "Mail sent successfully",logger.addScreenCapture(RecordingActions.takePageScreenShot(driver,"mailSuccess","Mail")));
	}
	/**
	 * @param subjectMail
	 * @throws InterruptedException
	 */
	public void viewMail(String subjectMail) throws InterruptedException {
		//System.out.println("check"+subjectMail);
		EWA.WaitUntilElementIsPresent(driver, indexMenu);
		indexMenu.click();
		//System.out.println("check "+subjectMail);
		String messageDetails="Not found";
		EWA.WaitUntilElementIsPresent(driver, inboxMailBoxesLists.get(0));
		//System.out.println("check"+subjectMail);
		for(WebElement inboxMailBoxesList : inboxMailBoxesLists) {
			if(inboxMailBoxesList.getText().equals(subjectMail)) {
				inboxMailBoxesList.click();
				List <WebElement> bodyElements = driver.findElements(By.xpath("//div[@class='ii gt']"));
				for (WebElement bodyElement :bodyElements) {
					if(bodyElement.isDisplayed()) {
						messageDetails=bodyElement.getText();
					}
				}
				break;
			}
		}
		logger.log(LogStatus.INFO, "Mail view", "Mail view "+messageDetails);
		RecordingActions.info("Mail viewed-"+messageDetails);
	}
	/**
	 * @param subjectMail
	 * @throws InterruptedException
	 */
	public void deleteMail(String subjectMail) throws InterruptedException {
		viewMail(subjectMail);
		Actions action = new Actions(driver);
		WebElement delBtn = driver.findElement(By.xpath("//*[@class=' G-atb D E']/div/div/div[2]/div[3]"));
		action.moveToElement(delBtn);
        //Thread.sleep(1000);
        action.click().perform();
        Thread.sleep(3000);
		logger.log(LogStatus.PASS, "Delete mail", "Delete mail as "+subjectMail);
		RecordingActions.info("Delete mail as "+subjectMail);
	}
	/**
	 * @param subjectMail
	 * @throws InterruptedException
	 */
	public void deleteMailDirect(String subjectMail) throws InterruptedException {
		//Thread.sleep(1000);
		//System.out.println("check "+subjectMail);
		int i=0;
		for(WebElement inboxMailBoxesList : inboxMailBoxesLists) {
			if(inboxMailBoxesList.getText().equals(subjectMail)) {
				//inboxMailBoxesList.click();
				inboxcheckMailBoxesLists.get(i).click();
				break;
			}
			i+=1;
		}
		Actions action = new Actions(driver);
		//WebElement delBtn = driver.findElement(By.xpath("//*[@aria-label='Delete']"));
		WebElement delBtn = driver.findElement(By.xpath("//*[@class='G-Ni G-aE J-J5-Ji']//div[3]"));
		action.moveToElement(delBtn);
        //Thread.sleep(1000);
        action.click().perform();
        Thread.sleep(3000);
		logger.log(LogStatus.PASS, "Delete mail", "Delete mail as "+subjectMail);
		RecordingActions.info("Delete mail as "+subjectMail);
	}
	/**
	 * @param subjectMail
	 * @throws InterruptedException
	 */
	public void backtoIndex(String subjectMail) throws InterruptedException {
		Actions action = new Actions(driver);
		WebElement backBtn = driver.findElement(By.xpath("//*[@class=' G-atb D E']/div/div/div/div"));
		action.moveToElement(backBtn);
        //Thread.sleep(1000);
        action.click().perform();
        Thread.sleep(5000);
	}
	/**
	 * @throws InterruptedException
	 */
	public void logout() throws InterruptedException {
		profileBtn.click();
		EWA.WaitUntilElementIsPresent(driver, signoutBtn);
		signoutBtn.click();
		logger.log(LogStatus.PASS, "logout mail", "Logout the Mail ID.");
		RecordingActions.info("Logout the Mail ID.");
		
	}
}
