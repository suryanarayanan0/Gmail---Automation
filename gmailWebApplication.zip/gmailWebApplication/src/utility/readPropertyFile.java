package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * @author surya
 * read the property file
 *
 */
public class readPropertyFile {
	public Properties prop = null;
	/**
	 * @throws IOException
	 */
	public readPropertyFile() throws IOException{
		 File file = new File("./config.properties");
		 FileInputStream objfile = new FileInputStream(file);
		 prop = new Properties();
		 prop.load(objfile);
	}
	/**
	 * @return test data path
	 */
	public String getTestDataPath(){
		return prop.getProperty("Path_TestData");
	}
	/**
	 * @return log details path
	 */
	public String getLogPath(){
		return prop.getProperty("Path_logdata");
	}
	/**
	 * @return browser information path
	 */
	public String getBrowser(){
		 return prop.getProperty("BROWSER");		  
	}
	/**
	 * @return  url details path
	 */
	public String getUrl(){
		 return prop.getProperty("URL");
	}
	/**
	 * @return driver path
	 */
	public String getChromeDriverPath() {	
		return prop.getProperty("ChromeDriverPath");
	}
}
