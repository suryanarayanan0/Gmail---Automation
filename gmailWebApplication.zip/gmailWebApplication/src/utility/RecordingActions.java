package utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;

/**
 * @author surya
 * Report record actions handle
 *
 */
public class RecordingActions {
	private WebDriver driver;
	protected ExtentTest logger;
	
	static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");	
	static String DF=dateFormat.format(new Date());
	
	public static Logger Log = null;
	/**
	 * @param driver
	 * @param logger
	 */
	public RecordingActions(WebDriver driver,ExtentTest logger){
		this.driver=driver;
		this.logger=logger;
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * @param driver
	 * @param Location
	 * @param name
	 * @return
	 * @throws IOException
	 */
	public static String takePageScreenShot(WebDriver driver,String Location,String name) throws IOException{
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir") + "/TestsScreenshots/"+Location+"/"+name+"-"+dateFormat.format(new Date())+"+.png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}
	// This is to print log for the beginning of the test case, as we usually run so many test cases as a test suite
	/**
	 * @param sTestCaseName
	 */
	public static void startTestCase(String sTestCaseName){ 
		Log.info("****************************************************************************************");
	 
		Log.info("****************************************************************************************");
	 
		Log.info("$$$$$$$$$$$$$$$$$$$$$                 "+sTestCaseName+ "       $$$$$$$$$$$$$$$$$$$$$$$$$");
	 
		Log.info("****************************************************************************************");
	 
		Log.info("****************************************************************************************");
	 
	} 
	//This is to print log for the ending of the test case
	/**
	 * @param sTestCaseName
	 */
	public static void endTestCase(String sTestCaseName){ 
		Log.info("XXXXXXXXXXXXXXXXXXXXXXX             "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");
	 
		Log.info("X");
	 
		Log.info("X");
	 
		Log.info("X");
	 
		Log.info("X");
	 
	} 
	// Need to create these methods, so that they can be called  
	public static void info(String message) { 
		Log.info(message); 
	} 
	public static void warn(String message) { 
		Log.warn(message);
	}
	public static void error(String message) { 
		Log.error(message);
	} 
	public static void fatal(String message) { 
	   Log.fatal(message);
	} 
	public static void debug(String message) {
		Log.debug(message);
	}
}
