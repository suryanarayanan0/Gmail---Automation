package utility;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author surya
 * Process XML values in the class
 *
 */
public class dataProviderActions {
	/**
	 * @param fileName
	 * @return
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	public Element ReadXml(String fileName) throws IOException, ParserConfigurationException, SAXException{
		readPropertyFile property = new readPropertyFile();
		File xmlFile = new File(property.getTestDataPath()+fileName+".xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(xmlFile);
		NodeList n1xml = doc.getChildNodes();
		Node nxml = n1xml.item(0);
		Element element = (Element)nxml;	
		return element;
	}
	/**
	 * @param fileName
	 * @param tagName
	 * @return
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	public Object[][] getXMLData(String fileName,String tagName) throws IOException, ParserConfigurationException, SAXException{
		Element ele = ReadXml(fileName);
		int size = ele.getElementsByTagName(tagName).getLength();
		String TestData =ele.getElementsByTagName(tagName).item(0).getTextContent();
		String[] FieldData=TestData.trim().split("[\\r\\n]+");
		int Columns=FieldData.length;
		
		int Rows=size;	
		
		Object[][] data = new Object[Rows][Columns];
		for(int i=0;i<Rows;i++)
		{	TestData =ele.getElementsByTagName(tagName).item(i).getTextContent();
			String[] XMLData=TestData.trim().split("[\\r\\n]+");
				for(int j=0;j<Columns;j++)
				{	
					data[i][j] = XMLData[j];
					System.out.println(XMLData[j]);
				}
		}
		return data;
	}
}
