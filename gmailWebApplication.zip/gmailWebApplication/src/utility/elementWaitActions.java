package utility;

import java.util.List;
//import java.util.concurrent.TimeUnit;
//import static java.util.concurrent.TimeUnit.SECONDS;
//import static java.util.concurrent.TimeUnit.MILLISECONDS;

import org.openqa.selenium.By;
//import org.openqa.selenium.ElementNotVisibleException;
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.FluentWait;
//import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

//import com.google.common.base.Function;
//import com.google.common.base.Predicate;

/**
 * @author surya
 * Element wait action handle in this class
 *
 */
public class elementWaitActions {
	private WebDriver driver;
	public static long TotalLoadingTime = 0;
	/**
	 * @param driver
	 */
	public elementWaitActions(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	/**
	 * WaitUntilElementIsPresent - waits until the passed webelement is clickable
	 * @param driver
	 * @param element
	 * @throws InterruptedException 
	 */
	public void WaitUntilElementIsPresent(WebDriver driver,WebElement element) throws InterruptedException
	{
		Thread.sleep(500);
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		
		wait.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(element)));	
	}
	
	/**
	 * WaitUntilElementIsVisible - waits until the passed webelement is clickable
	 * @param driver
	 * @param element
	 */
	public void WaitUntilElementIsVisible(WebDriver driver,WebElement element)
	{
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		
		wait.until(ExpectedConditions.visibilityOf(element));	
	}
	
	/**
	 * WaitUntilElementIsVisible - waits until the passed webelement is clickable
	 * @param driver
	 * @param element
	 */
	public void WaitUntilElementIsVisible(WebDriver driver,List<WebElement> element)
	{
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		
		wait.until(ExpectedConditions.visibilityOfAllElements(element));	
	}
	
	
	/**
	 * WaitUntilElementIsInvisible - waits until the passed webelements are invisible
	 * @param driver
	 * @param elements
	 */
	public void WaitUntilElementIsInvisible(WebDriver driver,List<WebElement> elements)
	{
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		
		wait.until(ExpectedConditions.invisibilityOfAllElements(elements));
		
	}
	
	/**
	 * invisibilityOfAllElements - waits until the element of passed locator is invisible
	 * @param driver
	 * @param locator
	 */
	public void WaitUntilElementIsInvisible(WebDriver driver,By locator)
	{
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		
		wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
		
	}
	
	/**
	 * WaitUntilElementIsEnabled - waits until the passed element is enabled
	 * @param driver
	 * @param element
	 */
	public void WaitUntilElementIsEnabled(WebDriver driver,WebElement element)
	{
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		
		wait.until(ExpectedConditions.refreshed(ExpectedConditions.attributeContains(element, "aria-disabled", "false")));	
	}
}
