package testScripts;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import utility.RecordingActions;
import utility.readPropertyFile;

/**
 * @author surya
 * Super class for all pre process and post process
 * Extent reports,Log details and driver details Process
 */
public class superTestNG {
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static WebDriver driver;
	
	SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");	
	String DTF=dateTimeFormat.format(new Date());
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");	
	String DF=dateFormat.format(new Date());
	/**
	 * @throws IOException
	 */
	@BeforeSuite
	public void precondition() throws IOException {
		readPropertyFile property = new readPropertyFile();
		System.out.println(property.getLogPath()+"\\OverAllReport-"+DF+".html");
		extent=new ExtentReports(property.getLogPath()+"\\OverAllReport-"+DF+".html",false);
		extent.loadConfig(new File(property.getLogPath()+"\\extent-config.xml"));
		logger = extent.startTest("Sample test");
		System.setProperty("webdriver.chrome.driver", property.getChromeDriverPath());
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		options.addArguments("incognito");
		driver = new ChromeDriver(options);
		//driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get(property.getUrl());
		String DTF=dateTimeFormat.format(new Date());
		System.setProperty("logfilename", property.getLogPath()+"\\log-"+DTF+".log");
		DOMConfigurator.configure(property.getLogPath()+"\\log4j.xml");
		RecordingActions.Log = Logger.getLogger("Gmail_test_log_reports");
		RecordingActions.startTestCase("Gmail_Test_reports");
	}
	/**
	 * Close all driver and reports details
	 */
	@AfterSuite
	public void postCondition() {
		driver.close();
		RecordingActions.endTestCase("Gmail_test_log_reports");
		extent.flush();
	}
	
}
