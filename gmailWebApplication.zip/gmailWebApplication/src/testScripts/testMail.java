package testScripts;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import pageObjects.gmailHomePage;
import pageObjects.gmailLoginPage;
import utility.dataProviderActions;

/**
 * @author surya
 * Test script for mail to process
 * Test script class with POM and testNG annotations
 *
 */
public class testMail extends  superTestNG{
	/**
	 * @param uname
	 * @param password
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@Test(priority=0,dataProvider = "Authentication")
	public void login(String uname,String password) throws IOException, InterruptedException{
		gmailLoginPage glp = new gmailLoginPage(driver,logger);
		glp.login(uname.trim(),password.trim());
	}
	/**
	 * @param toMail
	 * @param Subject
	 * @param Message
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	@Test(priority=1,dataProvider="Compose")
	public void composeMail(String toMail, String Subject, String Message) throws InterruptedException, IOException {
		gmailHomePage ghp = new gmailHomePage(driver,logger);
		ghp.composeMail(toMail.trim(), Subject.trim(), Message.trim());
	}
	/**
	 * @param subject
	 * @throws InterruptedException
	 */
	@Test(priority=2,dataProvider="DeleteMail")
	public void viewMail(String subject) throws InterruptedException {
		gmailHomePage ghp = new gmailHomePage(driver,logger);
		ghp.viewMail(subject.trim());
		ghp.backtoIndex(subject.trim());
	}
	/**
	 * @param subject
	 * @throws InterruptedException
	 */
	@Test(priority=3,dataProvider="DeleteMail")
	public void deleteMail(String subject) throws InterruptedException {
		gmailHomePage ghp = new gmailHomePage(driver,logger);
		//directly delete the mail
		ghp.deleteMailDirect(subject.trim());
		//open and delete mail
		//ghp.deleteMail(subject.trim());
		
	}
	/**
	 * @throws InterruptedException
	 */
	@Test(priority=4)
	public void LogoutMail() throws InterruptedException {
		gmailHomePage ghp = new gmailHomePage(driver,logger);
		ghp.logout();
	}
	/**
	 * @return
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	@DataProvider(name = "Authentication")
	public static Object[][] credentials() throws IOException, ParserConfigurationException, SAXException {
		dataProviderActions DPA = new dataProviderActions();
		return DPA.getXMLData("login_credential", "LOGINDETAILS");
    }
	/**
	 * @return
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	@DataProvider(name = "Compose")
	public static Object[][] compose() throws IOException, ParserConfigurationException, SAXException {
		dataProviderActions DPA = new dataProviderActions();
		return DPA.getXMLData("login_credential", "COMPOSEDETAILS");
    }
	/**
	 * @return
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	@DataProvider(name = "DeleteMail")
	public static Object[][] DeleteMail() throws IOException, ParserConfigurationException, SAXException {
		dataProviderActions DPA = new dataProviderActions();
		return DPA.getXMLData("login_credential", "VIEWMALL");
    }
}
