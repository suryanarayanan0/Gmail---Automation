Automate the gmail compose mail,view and delete the mail

Use basic packeage like as selenium stone alone,testNG,POI,extent report,log4j and etc
Make the Page Object Model for the Gmail for two pages

Testscripts and Utility package based to seperate the application.
SuperTestNG to based to preconditiona and post condition intialized.

Make the automation for Gmail compose module,view the mail and delete the mail.
Data Driven framework based to pass the data directly in all the modules.

Extent and log4j to pass and info or the all the process stages.
